<?php
namespace AD90\CustomNavMenu\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;

class MenuItem extends Entity
{
    protected function _preSave()
    {
        if ($this->menu_class !== '' && !preg_match('/^[a-zA-Z_][a-zA-Z0-9_-]*(?: [a-zA-Z_][a-zA-Z0-9_-]*)*$/D', $this->menu_class)) { $this->error(\XF::phrase('ad90_nav_invalid_class'), 'menu_class'); }
        if (!$this->native_id && (!$this->title || !$this->url)) { $this->error(\XF::phrase('ad90_nav_title_url_required')); }
        if (!\AD90\CustomNavMenu\Service\MenuTree::validUrl($this->url)) { $this->error(\XF::phrase('ad90_nav_invalid_url'), 'url'); }
        if ((bool)$this->permission_group !== (bool)$this->permission_id) { $this->error(\XF::phrase('ad90_nav_permission_pair')); }
        if ($this->permission_id && !\XF::em()->find('XF:Permission', [$this->permission_group, $this->permission_id]))
        { $this->error(\XF::phrase('ad90_nav_permission_missing')); }
        $repo = $this->repository('AD90\CustomNavMenu:Navigation');
        if ($this->native_id && !$this->getOption('skip_native_validation'))
        {
            if (!$this->exists() && !isset($repo->getNativeItems()[$this->native_id])) { $this->error(\XF::phrase('ad90_nav_native_missing')); }
            $duplicate = $this->finder('AD90\CustomNavMenu:MenuItem')->where('native_id', $this->native_id)->where('item_id', '<>', $this->item_id ?: 0)->fetchOne();
            if ($duplicate) { $this->error(\XF::phrase('ad90_nav_override_duplicate')); }

        }
        $parents = $repo->getParentMap();
        if ((!$this->native_id || $this->override_parent) && !$this->getOption('skip_parent_validation')
            && (!$this->exists() || $this->isChanged(['parent_key', 'override_parent'])))
        {
            $parents[$this->native_id ?: 'ad90_' . ($this->item_id ?: 'new')] = $this->parent_key;
            try { \AD90\CustomNavMenu\Service\MenuTree::validateParents($parents, 3, [$this->native_id ?: 'ad90_' . ($this->item_id ?: 'new')]); }
            catch (\InvalidArgumentException $e) { $this->error($e->getMessage(), 'parent_key'); }
        }
    }
    public function getPermissionTitle()
    {
        $native = $this->native_id ? $this->em()->find('XF:Navigation', $this->native_id) : null;
        return $native ? (string)$native->title : ($this->title ?: $this->native_id);
    }

    protected function _postSave()
    {
        \XF::app()->registry()->delete('ad90NavItems');
        if ($this->use_item_permission)
        {
            $id = 'item'.$this->item_id;
            $permission = $this->em()->find('XF:Permission', ['ad90Nav', $id]);
            if (!$permission)
            {
                $permission = $this->em()->create('XF:Permission');
                $permission->bulkSet(['permission_group_id'=>'ad90Nav', 'permission_id'=>$id, 'interface_group_id'=>'general', 'addon_id'=>'']);
                $permission->save();
                foreach ([1, 2] as $group)
                {
                    $entry = $this->em()->create('XF:PermissionEntry');
                    $entry->bulkSet(['user_group_id'=>$group, 'permission_group_id'=>'ad90Nav', 'permission_id'=>$id, 'permission_value'=>'allow']);
                    $entry->save();
                }
            }
            $phrase = $this->finder('XF:Phrase')->where('title', $permission->getPhraseName())->where('language_id', 0)->fetchOne() ?: $permission->getMasterPhrase();
            $phrase->phrase_text = $this->app()->language(0)->phrase('ad90_nav_permission_name', ['title'=>$this->getPermissionTitle()])->render('raw');
            $phrase->save();
            $permission->hydrateRelation('MasterTitle', $phrase);
            if ($this->isChanged('use_item_permission'))
            {
                \XF::app()->jobManager()->enqueueUnique('permissionRebuild', 'XF:PermissionRebuild');
            }
        }
    }
    protected function _preDelete()
    {
        if (!$this->native_id && $this->finder('AD90\CustomNavMenu:MenuItem')->where('parent_key', $this->native_id ?: 'ad90_' . $this->item_id)->total())
        { $this->error(\XF::phrase('ad90_nav_move_children')); }
    }
    protected function _postDelete()
    {
        \XF::app()->registry()->delete('ad90NavItems');
        $permission = $this->em()->find('XF:Permission', ['ad90Nav', 'item'.$this->item_id]);
        if ($permission) { $permission->delete(); }
        if ($this->icon_id) { \AD90\CustomNavMenu\Service\Icon::delete($this->icon_id); }
    }
    public static function getStructure(Structure $structure)
    {
        $structure->table = 'xf_ad90_nav_item'; $structure->shortName = 'AD90\CustomNavMenu:MenuItem'; $structure->primaryKey = 'item_id';
        $structure->columns = [
            'item_id'=>['type'=>self::UINT, 'autoIncrement'=>true, 'nullable'=>true],
            'native_id'=>['type'=>self::STR, 'maxLength'=>50, 'default'=>''],
            'native_managed'=>['type'=>self::BOOL, 'default'=>false],
            'is_group'=>['type'=>self::BOOL, 'default'=>false],
            'parent_key'=>['type'=>self::STR, 'maxLength'=>60, 'default'=>''],
            'title'=>['type'=>self::STR, 'maxLength'=>100, 'default'=>''],
            'url'=>['type'=>self::STR, 'maxLength'=>2048, 'default'=>''],
            'display_order'=>['type'=>self::UINT, 'default'=>100],
            'enabled'=>['type'=>self::BOOL, 'default'=>true],
            'target_blank'=>['type'=>self::BOOL, 'default'=>false],
            'permission_group'=>['type'=>self::STR, 'maxLength'=>25, 'default'=>''],
            'permission_id'=>['type'=>self::STR, 'maxLength'=>25, 'default'=>''],
            'override_parent'=>['type'=>self::BOOL, 'default'=>false],
            'use_item_permission'=>['type'=>self::BOOL, 'default'=>false],
            'description'=>['type'=>self::STR, 'maxLength'=>500, 'default'=>''],
            'section_title'=>['type'=>self::STR, 'maxLength'=>500, 'default'=>''],
            'menu_class'=>['type'=>self::STR, 'maxLength'=>100, 'default'=>''],
            'counter_source'=>['type'=>self::STR, 'maxLength'=>50, 'default'=>'native'],
            'icon_id'=>['type'=>self::UINT, 'default'=>0]
        ];
        $structure->options = ['skip_parent_validation'=>false, 'skip_native_validation'=>false];
        return $structure;
    }
}
