<?php
namespace AD90\CustomNavMenu\Service;

class NativeNavigation extends \XF\Service\AbstractService
{
    public function getItem($nativeId)
    {
        return $this->finder('AD90\CustomNavMenu:MenuItem')->where('native_id', $nativeId)->fetchOne()
            ?: $this->em()->create('AD90\CustomNavMenu:MenuItem');
    }

    public function getEditParams($nativeId)
    {
        $item = $this->getItem($nativeId);
        $icons = $this->repository('AD90\CustomNavMenu:Navigation')->getIconUris();
        $icon = $icons[$item->icon_id] ?? [];
        $nativeIds = $this->repository('AD90\CustomNavMenu:Navigation')->getNativeOrders();
        $runtimeParents = array_filter($this->repository('AD90\CustomNavMenu:Navigation')->getNativeItems(), function ($row) use ($nativeIds, $nativeId)
        { return !isset($nativeIds[$row['id']]) && $row['id'] !== $nativeId; });
        if ($item->override_parent && $item->parent_key !== '' && !isset($nativeIds[$item->parent_key]) && !isset($runtimeParents[$item->parent_key]))
        { $runtimeParents[$item->parent_key] = ['id'=>$item->parent_key, 'title'=>$item->parent_key]; }
        return ['ad90RuntimeParents'=>$runtimeParents, 'item'=>$item, 'currentIconSvg'=>$icon['svg'] ?? '', 'currentIconUri'=>$icon['uri'] ?? '',
            'counterSource'=>in_array($item->counter_source, ['native','none','threads','alerts','conversations'], true)
                ? $item->counter_source : 'custom'];
    }

    public function migrate()
    {
        $db = $this->db();
        $db->beginTransaction();
        try
        {
            $rows = $db->fetchAllKeyed('SELECT * FROM xf_ad90_nav_item ORDER BY item_id FOR UPDATE', 'item_id');
            $nativeIds = array_fill_keys($db->fetchAllColumn('SELECT navigation_id FROM xf_navigation'), true);
            $map = [];
            // Allocate all IDs before resolving parents. Retain item IDs for existing permission entries.
            foreach ($rows as $row)
            {
                if ($row['native_id'] !== '') { continue; }
                $oldId = 'ad90_'.$row['item_id'];
                $newId = $oldId;
                while (isset($nativeIds[$newId])) { $newId = 'ad90_'.bin2hex(random_bytes(8)); }
                $nativeIds[$newId] = true;
                $map[$oldId] = $newId;
            }
            foreach ($rows as $row)
            {
                if ($row['native_managed']) { continue; }
                $custom = $row['native_id'] === '';
                $id = $custom ? $map['ad90_'.$row['item_id']] : $row['native_id'];
                $nav = $this->em()->find('XF:Navigation', $id);
                if (!$custom && !$nav) { continue; } // Runtime entries keep their existing overlay settings.
                if ($custom)
                {
                    $nav = $this->em()->create('XF:Navigation');
                    $nav->bulkSet(['navigation_id'=>$id, 'addon_id'=>'', 'navigation_type_id'=>'basic',
                        'type_config'=>['link'=>self::literalUrl($row['url']), 'display_condition'=>'', 'extra_attributes'=>[]]]);
                }
                $nav->setOption('verify_parent', false); // Validate the complete graph below, not a partial migration.
                $nav->setOption('user_edit', true);
                $parent = $map[$row['parent_key']] ?? $row['parent_key'];
                $runtimeParent = ($custom || $row['override_parent']) && $parent !== '' && !isset($nativeIds[$parent]);
                if (($custom || $row['override_parent']) && !$runtimeParent) { $nav->parent_navigation_id = $parent; }
                $nav->display_order = $row['display_order'];
                $nav->enabled = $custom ? (bool)$row['enabled'] : ($nav->enabled && $row['enabled']);
                $nav->save();
                if ($custom)
                {
                    $phrase = $nav->getMasterPhrase();
                    $phrase->phrase_text = $row['title'];
                    $phrase->save();
                }
                $db->update('xf_ad90_nav_item', ['native_id'=>$id, 'native_managed'=>1,
                    'override_parent'=>$runtimeParent ? 1 : 0, 'parent_key'=>$parent], 'item_id = ?', $row['item_id']);
            }
            foreach ($map as $old=>$new)
            {
                if ($old !== $new) { $db->update('xf_ad90_nav_item', ['parent_key'=>$new], 'parent_key = ?', $old); }
            }
            // Old descriptions were used as category labels. Keep the stored value and render it as a heading.
            // Validate newly moved paths without imposing a new depth limit on existing XF trees.
            $parents = $db->fetchPairs('SELECT navigation_id, parent_navigation_id FROM xf_navigation');
            $changed = [];
            foreach ($rows as $row)
            {
                if (!$row['native_managed']) { $changed[] = $row['native_id'] ?: $map['ad90_'.$row['item_id']]; }
            }
            MenuTree::validateParents($parents, PHP_INT_MAX, $changed);
            $db->commit();
        }
        catch (\Throwable $e) { $db->rollback(); throw $e; }
        $this->app->registry()->delete('ad90NavItems');
        $this->repository('XF:Navigation')->rebuildNavigationCache();
    }

    // Escape XF template syntax while retaining literal link text after compilation.
    public static function literalUrl($url)
    {
        return strpbrk($url, '{$<') === false ? $url : '{{ '.var_export($url, true).' }}';
    }

}
