(() => {
    'use strict';
    function markCurrentNavigation() {
        // Compare resolved URLs, including query routes used without friendly URLs.
        const key = value => {
            try {
                const url = new URL(value, document.baseURI);
                if (!/^https?:$/.test(url.protocol)) return null;
                url.hash = '';
                url.pathname = url.pathname.replace(/\/+$/, '') || '/';
                const parts = url.search.slice(1).split('&');
                // XF's first bare query component is the route, not a parameter.
                const route = parts[0] && !parts[0].includes('=') ? parts.shift().replace(/\/+$/, '') : null;
                if (route !== null) url.search = parts.join('&');
                url.searchParams.sort();
                return url.origin + url.pathname + (route !== null ? '?' + route + '&' + url.searchParams.toString() : url.search);
            } catch (_) { return null; }
        };
        const current = key(location.href);
        const nodes = new Map();
        document.querySelectorAll('.ad90-nav [data-nav-id], .ad90-nav-dropdown [data-nav-id], .ad90-mobile-drawer [data-nav-id]').forEach(link => {
            const id = link.dataset.navId;
            if (!nodes.has(id)) nodes.set(id, []);
            nodes.get(id).push(link);
        });
        const selected = new Set();
        nodes.forEach((links, id) => {
            links.forEach(link => {
                const href = link.getAttribute('href');
                if (!href || href.startsWith('#') || key(href) !== current) return;
                link.classList.add('is-selected');
                link.setAttribute('aria-current', 'page');
                let cursor = id;
                while (cursor && !selected.has(cursor)) {
                    selected.add(cursor);
                    cursor = nodes.get(cursor)?.[0].dataset.ad90Parent;
                }
            });
        });
        if (!selected.size) return; // Preserve XF's section selection on detail pages.
        document.querySelectorAll('.ad90-nav .p-nav-list .p-navEl.is-selected').forEach(item => item.classList.remove('is-selected'));
        nodes.forEach((links, id) => {
            if (selected.has(id)) links.forEach(link => link.closest('.p-navEl')?.classList.add('is-selected'));
        });
    }
    function updateVariationLink(link) {
        const choice = XF.StyleVariation.getColorScheme() === 'dark' ? 'light' : 'dark';
        link.href = link.dataset[choice + 'Url'];
        const label = link.dataset[choice + 'Label'];
        if (label) {
            link.setAttribute('aria-label', label);
            link.setAttribute('title', label);
            const tooltip = XF.Element.getHandler(link, 'tooltip');
            link.setAttribute('data-original-title', label);
            if (tooltip) tooltip.refresh();
        }
        link.querySelectorAll('[data-ad90-choice]').forEach(label => {
            label.classList.toggle('u-hidden', label.dataset.ad90Choice !== choice);
        });
    }
    // XF also activates this handler inside the AJAX-loaded account menu.
    XF.Element.register('ad90-variation-toggle', XF.Element.newHandler({
        init() { updateVariationLink(this.target); }
    }));
    document.addEventListener('click', event => {
        const link = event.target.closest('a[data-ad90-preference]');
        if (!link) return;
        if (link.classList.contains('ad90-variation-toggle')) updateVariationLink(link);
        // Preserve XF's index.php?misc/... route, which URLSearchParams would encode.
        link.href += (link.href.includes('?') ? '&' : '?') + '_xfRedirect=' + encodeURIComponent(location.href);
    }, true);
    let audioContext;
    let sound = false;
    const storageKey = 'ad90-nav-sound';
    try { sound = localStorage.getItem(storageKey) === '1'; } catch (_) { /* Storage may be disabled. */ }
    function beep() {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return;
        audioContext = audioContext || new AudioContext();
        audioContext.resume().then(() => {
            const oscillator = audioContext.createOscillator();
            const gain = audioContext.createGain();
            oscillator.connect(gain);
            gain.connect(audioContext.destination);
            oscillator.frequency.value = 660;
            gain.gain.setValueAtTime(0.06, audioContext.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.18);
            oscillator.start();
            oscillator.stop(audioContext.currentTime + 0.18);
        }).catch(() => { /* Browser requires a user gesture before playback. */ });
    }
    function updateSoundButtons() {
        document.querySelectorAll('.ad90-sound').forEach(button => button.setAttribute('aria-pressed', String(sound)));
    }
    function applyFilter(menu) {
        const active = menu.querySelector('[data-ad90-filter][aria-pressed="true"]');
        const filter = active ? active.dataset.ad90Filter : 'all';
        const marketTypes = (menu.dataset.marketTypes || '').split(',').map(type => type.trim()).filter(Boolean);
        menu.querySelectorAll('[data-ad90-content-type]').forEach(row => {
            const market = marketTypes.includes(row.dataset.ad90ContentType);
            row.hidden = filter === 'market' ? !market : filter === 'other' ? market : false;
        });
    }
    document.addEventListener('click', event => {
        const toggle = event.target.closest('.ad90-sound');
        if (toggle) {
            sound = !sound;
            try { localStorage.setItem(storageKey, sound ? '1' : '0'); } catch (_) { /* Optional persistence. */ }
            updateSoundButtons();
            if (sound) beep();
        }
        const filter = event.target.closest('[data-ad90-filter]');
        if (filter) {
            const menu = filter.closest('.ad90-nav-alerts');
            if (!menu) return;
            menu.querySelectorAll('[data-ad90-filter]').forEach(button => button.setAttribute('aria-pressed', String(button === filter)));
            applyFilter(menu);
        }
    });
    // Hover must not move focus away from the current control.
    // Mouse links navigate immediately; touch links open first, then navigate.
    const HOVER_OPEN_DELAY = 250;
    const HOVER_SWITCH_DELAY = 250;
    function setupResponsiveAccount() {
        const header = document.querySelector('.ad90-nav');
        if (!header) return;
        let frame;
        const update = () => {
            cancelAnimationFrame(frame);
            frame = requestAnimationFrame(() => {
                const top = Math.max(0, Math.min(innerHeight, header.getBoundingClientRect().bottom));
                document.documentElement.style.setProperty('--ad90-account-top', top + 'px');
            });
        };
        new ResizeObserver(update).observe(header);
        window.addEventListener('resize', update, {passive: true});
        // Sample the height budget on open/resize, not on every scroll frame.
        // The panel moves with its sticky ancestor without resizing its scrollport.
        window.visualViewport?.addEventListener('resize', update, {passive: true});
        XF.on(document, 'menu:opened', event => {
            if (event.target.matches('.ad90-nav-account')) update();
        });
        update();
        document.addEventListener('click', event => {
            if (!event.target.closest('.ad90-nav-account .ad90-account-close')) return;
            event.preventDefault();
            const trigger = header.querySelector('.p-navgroup-link--user[data-xf-click~="menu"]');
            const handler = trigger && XF.Event.initElement(trigger, 'click')?.menu;
            if (handler) { handler.close(); trigger.focus({preventScroll: true}); }
        });
    }
    function setupHoverMenus() {
        const triggerSelector = '[data-xf-click~="menu"]';
        const scopeSelector = '.ad90-nav, .ad90-nav-popup, .ad90-nav-dropdown';
        const drawerLinkSelector = '.ad90-mobile-drawer .offCanvasMenu-linkHolder > a[href]:not(.offCanvasMenu-link--splitToggle)';
        // Parent text and chevron share one native XF menu trigger.
        const hoverTrigger = target => target.closest(triggerSelector)
            || target.closest('.ad90-nav .p-navEl[data-has-children="true"]')?.querySelector(':scope > [data-xf-click~="menu"]');
        const hoverArea = trigger => trigger.closest('.ad90-nav .p-navEl') || trigger;
        const triggers = new WeakMap();
        const menus = new WeakMap();
        let opening;
        let lastPointer;
        const hoverOpened = new Set();
        const allStates = new Set();
        function cancelClose(state) {
            for (let current = state; current; current = current.parent) clearTimeout(current.closeTimer);
        }
        function inside(state, node) {
            if (!node) return false;
            if (hoverArea(state.trigger).contains(node) || state.menu.contains(node)) return true;
            for (const child of allStates) {
                for (let parent = child.parent; parent; parent = parent.parent) {
                    if (parent === state && child.menu.contains(node)) return true;
                }
            }
            return false;
        }
        function stateFor(trigger) {
            let state = triggers.get(trigger);
            if (state) return state;
            const initialised = XF.Event.initElement(trigger, 'click');
            const handler = initialised && initialised.menu;
            if (!handler || !handler.menu) return null;
            state = {trigger, handler, menu: handler.menu};
            const anchor = trigger.closest('.ad90-nav')?.closest('.ad90-header-slot');
            if (anchor) {
                // Keep the panel in the same sticky coordinate system as its trigger.
                // Native XF moves body-level panels between absolute/fixed on scroll;
                // descendants of the sticky slot move together without scroll-time writes.
                const reposition = handler.reposition.bind(handler);
                const horizontal = handler.getHorizontalPosition.bind(handler);
                handler.reposition = function (force) {
                    if (state.menu.parentElement !== anchor) anchor.append(state.menu);
                    reposition(force, true);
                };
                handler.getHorizontalPosition = function (viewport, css) {
                    css = horizontal(viewport, css);
                    css.left = (parseFloat(css.left) - anchor.getBoundingClientRect().left
                        - window.scrollX - anchor.clientLeft + anchor.scrollLeft) + 'px';
                    return css;
                };
                handler.getVerticalPosition = function (viewport, css) {
                    this.menuIsUp = false;
                    state.menu.classList.remove('menu--up');
                    css.position = 'absolute';
                    css.top = (this.menuRef.bottom - window.scrollY - anchor.getBoundingClientRect().top
                        - anchor.clientTop + anchor.scrollTop - this.getTopShift()) + 'px';
                    return css;
                };
                // XF still checks hidden triggers and handles close/resize/AJAX normally.
                handler.repositionFixed = function () {};
            }
            const parent = menus.get(trigger.closest('.menu'));
            state.parent = parent;
            triggers.set(trigger, state);
            menus.set(state.menu, state);
            allStates.add(state);
            // XF 2.3 always focuses a completed menu, even without an input.
            // Hover must not take focus from an editor or search elsewhere.
            state.menu.addEventListener('focusin', event => {
                if (!hoverOpened.has(state)) return;
                if (state.previousFocus && state.previousFocus.isConnected && !state.previousFocus.closest('.menu')) {
                    state.previousFocus.focus({preventScroll: true});
                } else event.target.blur();
            });
            // XF dispatches this event on both menu and trigger; cleanup is idempotent.
            [state.menu, state.trigger].forEach(node => {
                XF.on(node, 'menu:closed', () => { clearTimeout(state.closeTimer); hoverOpened.delete(state); });
            });
            return state;
        }
        // Close the previous menu before opening another so XF does not treat them as nested.
        // CSS keeps the closing panel visible during the transition.
        function closeOthers(except) {
            const keep = new Set();
            for (let current = except.parent; current; current = current.parent) keep.add(current);
            let restore = null;
            allStates.forEach(other => {
                if (other === except || keep.has(other) || !other.handler.isOpen()) return;
                const saved = other.previousFocus;
                if (!restore && saved && saved.isConnected && !saved.closest('.menu')) restore = saved;
                hoverOpened.delete(other);
                other.handler.close();
            });
            return restore;
        }
        document.addEventListener('pointerover', event => {
            if (event.pointerType !== 'mouse' || event.sourceCapabilities?.firesTouchEvents) return;
            const panel = menus.get(event.target.closest('.menu'));
            if (panel) cancelClose(panel);
            const trigger = hoverTrigger(event.target);
            if (!trigger || !trigger.closest(scopeSelector)) return;
            const area = hoverArea(trigger);
            if (area.contains(event.relatedTarget)) return;
            // XF only switches modality on mousedown; a hover must switch it before restoring focus too.
            XF.NavDeviceWatcher.toggle(false);
            clearTimeout(opening);
            const state = stateFor(trigger);
            if (!state) return;
            cancelClose(state);
            if (state.handler.isOpen()) return;
            const switching = Array.from(allStates).some(other => other !== state && other.handler.isOpen()
                && !inside(other, trigger));
            // Keep the current panel until the next hover is confirmed.
            opening = setTimeout(() => {
                if (trigger.isConnected && area.matches(':hover') && !state.handler.isOpen()) {
                    const active = document.activeElement;
                    const inMenu = !!(active && active.closest && active.closest('.menu'));
                    const restore = closeOthers(state);
                    // Focus that sits inside a menu is not worth restoring: use what the user had before that menu.
                    state.previousFocus = inMenu ? restore : active;
                    hoverOpened.add(state);
                    // Same as the 2.2 script: no autofocus when opened by hover.
                    if (state.handler.options) state.handler.options.menuAutofocus = false;
                    state.handler.open(false);
                }
            }, switching ? HOVER_SWITCH_DELAY : HOVER_OPEN_DELAY);
        });
        document.addEventListener('pointerout', event => {
            if (event.pointerType !== 'mouse') return;
            const trigger = hoverTrigger(event.target);
            const state = (trigger && triggers.get(trigger)) || menus.get(event.target.closest('.menu'));
            if (!state || inside(state, event.relatedTarget)) return;
            clearTimeout(opening);
            // Leaving cancels a pending open; an already open menu stays open.

        });
        // Keep native link navigation after mouse/keyboard activation. A touch on a
        // closed linked trigger previews its menu; the next touch follows the link.
        window.addEventListener('click', event => {
            const drawerLink = event.target.closest(drawerLinkSelector);
            const trigger = drawerLink || event.target.closest(triggerSelector);
            if (!trigger || (!drawerLink && !trigger.closest(scopeSelector))) return;
            const touch = event.pointerType === 'touch' || event.sourceCapabilities?.firesTouchEvents
                || (!event.pointerType && event.detail > 0 && lastPointer?.type === 'touch'
                    && lastPointer.trigger === trigger && performance.now() - lastPointer.at < 1500);
            lastPointer = null;
            if (drawerLink) {
                const toggle = drawerLink.parentElement.querySelector('.offCanvasMenu-link--splitToggle');
                if (touch && toggle && !toggle.classList.contains('is-active') && event.button === 0
                    && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) {
                    event.preventDefault();
                    event.stopPropagation();
                    toggle.click(); // Let XF expand its existing off-canvas sublist.
                }
                return;
            }
            const state = stateFor(trigger);
            if (state) hoverOpened.delete(state);
            const href = trigger.getAttribute('href');
            if (trigger.matches('a[href]') && href && href !== '#') {
                // Prevent XF from consuming a navigation as a toggle.
                event.stopPropagation();
                if (touch && state && !state.handler.isOpen() && !event.ctrlKey && !event.metaKey
                    && !event.shiftKey && !event.altKey && event.button === 0) {
                    event.preventDefault();
                    closeOthers(state);
                    state.handler.open(true);
                } else if (state && state.handler.isOpen()) state.handler.close();
            }
        }, true);
        // A press cancels a pending hover-open (the click then opens the menu itself and pins it).
        function resumeInteraction(event) {
            clearTimeout(opening);
            if (event.type === 'pointerdown') {
                lastPointer = {type: event.pointerType, trigger: event.target.closest(drawerLinkSelector) || event.target.closest(triggerSelector), at: performance.now()};
            }
            if (event.type === 'keydown') {
                lastPointer = null;
                allStates.forEach(state => clearTimeout(state.closeTimer));
                hoverOpened.clear(); // Keyboard interaction hands closing back to XF.
            }
        }
        document.addEventListener('pointerdown', resumeInteraction, true);
        document.addEventListener('keydown', resumeInteraction, true);
    }
    // The panels are hidden with visibility, which already removes them from the accessibility tree.
    // A static aria-hidden="true" made Chrome block it as soon as XF focused the opened panel
    // ("Blocked aria-hidden ... element that just received focus"), so the attribute is never kept.
    const panelSelector = '.ad90-nav-popup, .ad90-nav-dropdown';
    function stripAriaHidden(root) {
        (root.matches && root.matches(panelSelector) ? [root] : []).concat(Array.from(root.querySelectorAll ? root.querySelectorAll(panelSelector) : []))
            .forEach(menu => menu.removeAttribute('aria-hidden'));
    }
    function setupLinkFeedback() {
        const pending = new Map();
        function restore(link) {
            clearTimeout(pending.get(link));
            pending.delete(link);
            link.classList.remove('is-ad90-pending');
        }
        document.addEventListener('click', event => {
            if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
            const link = event.target.closest('a.menu-linkRow, a.blockLink, .ad90-manage-item');
            if (!link || !link.closest('.ad90-nav-popup, .ad90-nav-dropdown')) return;
            // Menu triggers open a panel rather than starting a navigation/action.
            if (link.matches('[data-xf-click~="menu"], [target="_blank"], [download]')) return;
            restore(link);
            link.classList.add('is-ad90-pending');
            pending.set(link, setTimeout(() => restore(link), 1500));
        });
        XF.on(document, 'ajax:complete', () => pending.forEach((timer, link) => restore(link)));
        window.addEventListener('pageshow', () => pending.forEach((timer, link) => restore(link)));
    }
    function refreshNavigationCounters() {
        const nodes = new Map();
        document.querySelectorAll('.ad90-nav [data-nav-id], .ad90-nav-dropdown [data-nav-id], .ad90-mobile-drawer [data-nav-id]').forEach(link => {
            if (!nodes.has(link.dataset.navId)) nodes.set(link.dataset.navId, []);
            nodes.get(link.dataset.navId).push(link);
        });
        const live = {};
        ['alerts', 'conversations'].forEach(source => {
            const badge = document.querySelector('.ad90-nav .js-badge--' + source);
            if (badge) live[source] = Number((badge.dataset.badge || '').replace(/\D/g, ''));
        });
        const totals = new Map();
        function total(id) {
            if (totals.has(id)) return totals.get(id);
            const link = nodes.get(id)[0];
            const children = Array.from(nodes.keys()).filter(key => nodes.get(key)[0].dataset.ad90Parent === id);
            const value = children.length ? children.reduce((sum, key) => sum + total(key), 0)
                : (live[link.dataset.ad90CounterSource] ?? Number(link.dataset.ad90Counter || 0));
            totals.set(id, value);
            return value;
        }
        nodes.forEach((links, id) => {
            const value = total(id);
            links.forEach(link => {
                link.classList.toggle('ad90-has-unread', value > 0);
                let badge = link.querySelector('.ad90-unread-count');
                if (!value) { if (badge) badge.remove(); return; }
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'ad90-unread-count u-srOnly';
                    link.append(badge);
                }
                badge.textContent = '+' + value.toLocaleString();
            });
        });
    }
    // Keep XF's Ajax replacement synchronous; bridge the first paint with a decorative snapshot.
    // Recentpages overlay thumb: proportional size, 32px minimum, 700ms scroll hint.
    function setupMenuScrollbars() {
        document.querySelectorAll('.ad90-nav-popup').forEach(menu => {
            const states = new Map();
            let frame;
            const schedule = () => {
                if (!frame) frame = requestAnimationFrame(() => { frame = null; refresh(); });
            };
            const attach = viewport => {
                const wrapper = document.createElement('div');
                wrapper.className = 'ad90-menu-scroll';
                viewport.before(wrapper);
                wrapper.append(viewport);
                viewport.classList.add('ad90-menu-scroll-viewport');
                const thumb = document.createElement('div');
                thumb.className = 'ad90-menu-scroll-thumb';
                thumb.setAttribute('aria-hidden', 'true');
                wrapper.append(thumb);
                let timer, drag;
                const metrics = () => {
                    const height = viewport.clientHeight, total = viewport.scrollHeight;
                    const size = Math.min(height, Math.max(32, height * height / (total || 1)));
                    return {size, track: height - size, max: total - height};
                };
                const update = () => {
                    const m = metrics(), needed = m.max > 1 && viewport.clientHeight > 0;
                    thumb.style.display = needed ? 'block' : 'none';
                    thumb.style.height = m.size + 'px';
                    thumb.style.transform = 'translateY(' + (needed ? Math.max(0, Math.min(m.max, viewport.scrollTop)) / m.max * m.track : 0) + 'px)';
                };
                const scroll = () => {
                    update();
                    thumb.classList.add('is-scrolling');
                    clearTimeout(timer);
                    timer = setTimeout(() => thumb.classList.remove('is-scrolling'), 700);
                };
                const endDrag = () => {
                    const pointerId = drag?.id;
                    drag = null;
                    thumb.classList.remove('is-drag');
                    if (pointerId !== undefined && thumb.hasPointerCapture(pointerId)) thumb.releasePointerCapture(pointerId);
                };
                thumb.addEventListener('pointerdown', event => {
                    if (event.button !== 0 || drag) return;
                    event.preventDefault();
                    drag = {id: event.pointerId, y: event.clientY, top: viewport.scrollTop};
                    thumb.classList.add('is-drag');
                    thumb.setPointerCapture(event.pointerId);
                });
                thumb.addEventListener('pointermove', event => {
                    if (!drag || drag.id !== event.pointerId) return;
                    const m = metrics();
                    if (m.track > 0) viewport.scrollTop = drag.top + (event.clientY - drag.y) * m.max / m.track;
                });
                ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(name => thumb.addEventListener(name, endDrag));
                viewport.addEventListener('scroll', scroll, {passive: true});
                const resize = new ResizeObserver(schedule);
                let observed = [];
                const observe = () => {
                    const nodes = [viewport, ...viewport.children];
                    if (nodes.length === observed.length && nodes.every((node, index) => node === observed[index])) return;
                    observed = nodes;
                    resize.disconnect();
                    nodes.forEach(node => resize.observe(node));
                };
                states.set(viewport, {update, observe, endDrag, destroy() {
                    endDrag();
                    resize.disconnect(); clearTimeout(timer); viewport.removeEventListener('scroll', scroll);
                }});
                observe();
            };
            const refresh = () => {
                states.forEach((state, viewport) => {
                    if (!menu.contains(viewport)) { state.destroy(); states.delete(viewport); }
                });
                menu.querySelectorAll('.js-convMenuBody, .js-alertsMenuBody, .ad90-account-scroll').forEach(viewport => {
                    if (!states.has(viewport)) attach(viewport);
                });
                states.forEach(state => { state.observe(); state.update(); });
            };
            new MutationObserver(schedule).observe(menu, {childList: true, subtree: true,
                attributes: true, attributeFilter: ['hidden', 'open']});
            menu.addEventListener('load', schedule, true);
            XF.on(menu, 'menu:opened', schedule);
            XF.on(menu, 'menu:loaded', schedule);
            XF.on(menu, 'menu:closed', () => states.forEach(state => state.endDrag()));
            window.addEventListener('resize', schedule, {passive: true});
            refresh();
        });
    }
    function setupLoadingTransitions() {
        const pending = new WeakMap();
        const running = new WeakMap();
        const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const menuFrom = event => event.target.matches('[data-xf-click~="menu"]')
            && event.menu && event.menu.matches('.ad90-nav-popup') ? event.menu : null;
        const finish = menu => {
            const cleanup = running.get(menu);
            if (cleanup) cleanup();
        };
        XF.on(document, 'menu:opened', event => {
            const menu = menuFrom(event);
            if (!menu) return;
            finish(menu);
            pending.delete(menu);
            const loader = menu.querySelector('.ad90-menu-progress');
            const content = menu.querySelector('.menu-content');
            if (!loader || !content || reduced()) return;
            const box = content.getBoundingClientRect();
            const rect = loader.getBoundingClientRect();
            pending.set(menu, {clone: loader.cloneNode(true), height: box.height,
                top: rect.top - box.top - content.clientTop});
        }, {capture: true});
        XF.on(document, 'menu:loaded', event => {
            const menu = menuFrom(event);
            if (!menu) return;
            const before = pending.get(menu);
            pending.delete(menu);
            const content = menu.querySelector('.menu-content');
            if (!before || !content || !menu.classList.contains('is-active') || reduced() || !content.animate) return;
            const height = content.getBoundingClientRect().height;
            const target = menu.dataset.loadTarget ? menu.querySelector(menu.dataset.loadTarget) : content;
            if (!target) return;
            const nodes = target === content ? [...content.children] : [target];
            const overlay = before.clone;
            overlay.removeAttribute('role');
            overlay.removeAttribute('aria-label');
            overlay.setAttribute('aria-hidden', 'true');
            overlay.classList.add('ad90-loading-overlay');
            overlay.style.top = before.top + 'px';
            content.append(overlay);
            const overflow = content.style.overflow;
            content.style.overflow = 'hidden';
            const options = {duration: 100, easing: 'ease-out'};
            const animations = [
                content.animate([{height: before.height + 'px'}, {height: height + 'px'}], options),
                overlay.animate([{opacity: 1}, {opacity: 0}], {...options, fill: 'forwards'}),
                ...nodes.map(node => node.animate([{opacity: 0}, {opacity: 1}], options))
            ];
            let done = false;
            const cleanup = () => {
                if (done) return;
                done = true;
                animations.forEach(animation => animation.cancel());
                overlay.remove();
                content.style.overflow = overflow;
                running.delete(menu);
            };
            running.set(menu, cleanup);
            Promise.all(animations.map(animation => animation.finished)).then(() => {
                cleanup();
                const handlers = XF.Event.initElement(event.target, 'click');
                if (menu.classList.contains('is-active') && handlers && handlers.menu) {
                    handlers.menu.updateMenuDimensions();
                    handlers.menu.reposition();
                }
            }).catch(cleanup);
        }, {capture: true});
        XF.on(document, 'menu:closed', event => {
            const menu = menuFrom(event);
            if (menu) { pending.delete(menu); finish(menu); }
        }, {capture: true});
    }
    function prepareMobileTriggers() {
        // XF clones desktop links, including their menu handler attributes.
        document.querySelectorAll('.ad90-mobile-drawer a.ad90-parent-trigger[data-xf-click="menu"]').forEach(link => {
            const holder = link.closest('.offCanvasMenu-linkHolder');
            const toggle = holder && holder.querySelector('.offCanvasMenu-link--splitToggle');
            if (!toggle) return;
            const replacement = link.cloneNode(true);
            ['data-xf-click', 'data-menu-pos-ref', 'aria-controls', 'aria-expanded', 'aria-haspopup'].forEach(name => replacement.removeAttribute(name));
            link.replaceWith(replacement);
        });
    }
    function setup() {
        const refreshPreferenceLinks = () => document.querySelectorAll('.ad90-variation-toggle').forEach(updateVariationLink);
        XF.on(document, 'xf:variation-change', refreshPreferenceLinks);
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', refreshPreferenceLinks);
        XF.on(document, 'menu:closed', event => {
            const trigger = event.target;
            if (trigger.matches('[data-xf-click~="menu"]') && trigger.closest('.ad90-nav, .ad90-nav-popup')
                && event.menu && event.menu.contains(document.activeElement) && XF.NavDeviceWatcher.isKeyboardNav()) {
                trigger.focus({preventScroll: true});
            }
        }, {capture: true});
        stripAriaHidden(document);
        // Cached or third-party markup and XF itself may still put the attribute back: remove it before focus.
        new MutationObserver(records => records.forEach(record => {
            if (record.target.matches(panelSelector) && record.target.getAttribute('aria-hidden') === 'true') record.target.removeAttribute('aria-hidden');
        })).observe(document.body, {attributes: true, attributeFilter: ['aria-hidden'], subtree: true});
        refreshNavigationCounters();
        markCurrentNavigation();
        const mobileTarget = document.querySelector('.ad90-mobile-drawer .js-offCanvasNavTarget');
        if (mobileTarget) {
            new MutationObserver(records => {
                if (records.some(record => Array.from(record.addedNodes).some(node => node.nodeType === 1
                    && (node.matches('[data-nav-id]') || node.querySelector('[data-nav-id]'))))) { prepareMobileTriggers(); refreshNavigationCounters(); markCurrentNavigation(); }
            }).observe(mobileTarget, {childList: true, subtree: true});
        }
        setupMenuScrollbars();
        setupLoadingTransitions();
        setupHoverMenus();
        setupResponsiveAccount();
        setupLinkFeedback();
        updateSoundButtons();
        document.querySelectorAll('.ad90-nav-alerts').forEach(menu => {
            new MutationObserver(() => applyFilter(menu)).observe(menu.querySelector('.js-alertsMenuBody'), {childList: true, subtree: true});
        });
        document.querySelectorAll('.ad90-nav .js-badge--alerts, .ad90-nav .js-badge--conversations').forEach(badge => {
            let previous = Number((badge.dataset.badge || '').replace(/\D/g, ''));
            new MutationObserver(() => {
                const current = Number((badge.dataset.badge || '').replace(/\D/g, ''));
                if (sound && current > previous) beep();
                previous = current;
                refreshNavigationCounters();
            }).observe(badge, {attributes: true, attributeFilter: ['data-badge']});
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup, {once: true});
    else setup();
})();
