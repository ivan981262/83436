(() => {
    'use strict';
    // Loaded only on the AD90 style-property group. Keep XF's picker and stored LESS expressions.
    const nativeParse = XF.Color.fromValue;
    XF.Color.fromValue = (value, variation = 'default') => {
        if (typeof value !== 'string') return nativeParse(value, variation);
        value = value.trim().replace(/;\s*$/, '');
        const match = value.match(/^(fade|fadein|fadeout)\((.*)\)$/i);
        if (match) {
            let depth = 0, split = -1;
            for (let i = 0; i < match[2].length; i++) {
                const char = match[2][i];
                if (char === '(') depth++;
                else if (char === ')') depth--;
                else if (char === ',' && depth === 0) {
                    if (split !== -1) return null;
                    split = i;
                }
            }
            if (split === -1 || depth !== 0) return null;
            const raw = match[2].slice(split + 1).trim();
            if (!/^[+-]?(?:\d+\.?\d*|\.\d+)%?$/.test(raw)) return null;
            const color = XF.Color.fromValue(match[2].slice(0, split), variation);
            if (!color) return null;
            const amount = parseFloat(raw) / 100;
            const alpha = match[1].toLowerCase() === 'fade' ? amount
                : color.alpha + (match[1].toLowerCase() === 'fadein' ? amount : -amount);
            return color.set({alpha});
        }
        return nativeParse(value, variation);
    };
    // Remove an optional declaration terminator before XF updates the preview or serializes the form.
    const normalize = input => {
        if (input.matches('input[name^="properties[ad90Nav"]') && input.closest('[data-xf-init~="color-picker"]')) {
            input.value = input.value.trim().replace(/;\s*$/, '');
        }
    };
    document.addEventListener('input', event => normalize(event.target), true);
    document.addEventListener('submit', event => {
        event.target.querySelectorAll('input[name^="properties[ad90Nav"]').forEach(normalize);
    }, true);
    XF.trigger(document, 'color-picker:reparse');
})();
