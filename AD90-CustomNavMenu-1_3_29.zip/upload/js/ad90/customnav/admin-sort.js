(() => {
    'use strict';

    XF.Element.register('ad90-nav-sort', XF.Element.newHandler({
        init() {
            const handler = XF.Element.getHandler(this.target, 'nestable');
            if (!handler || !handler.nestable) return;
            const list = handler.nestable;
            const nativeMove = list.dragMove;
            const container = this.target;
            list.dragMove = function(event) {
                const element = document.elementFromPoint(event.clientX, event.clientY);
                const item = element && element.closest('.nestable-item');
                const ownItem = item && item.closest('.ad90-nav-sort') === container;
                // The XF nestable handler compares pageY with offsetTop, which is relative to
                // the nested list. Capture the viewport midpoint before moving.
                const rect = ownItem ? item.getBoundingClientRect() : null;
                const before = rect && event.clientY < rect.top + rect.height / 2;
                nativeMove.call(this, event);
                // Keep XF's depth/group/reparenting checks. Only adjust the
                // insertion side after XF accepts this item and parent list.
                if (ownItem && this.dragEl && this.pointEl === item
                    && this.mouse.dirAx === 0 && this.placeEl.parentNode === item.parentNode) {
                    item.parentNode.insertBefore(this.placeEl, before ? item : item.nextSibling);
                }
            };
        }
    }));
})();
